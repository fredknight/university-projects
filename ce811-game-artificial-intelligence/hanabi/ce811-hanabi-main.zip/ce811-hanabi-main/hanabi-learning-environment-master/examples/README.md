To build the C++ example (assuming you are running from the example directory):
```
pip install cmake                   # if you don't already have CMake
cmake .
make
```
to run:
```
./game_example 
```
